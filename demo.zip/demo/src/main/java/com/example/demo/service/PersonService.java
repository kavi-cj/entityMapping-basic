package com.example.demo.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.entity.Person;
import com.example.demo.repo.PersonRepository;

@Service
public class PersonService {
	
	@Autowired
	private PersonRepository personRepository;
	
	public Optional<Person> getPersonById(Long id){
		return personRepository.findById(id);
	}

	public Person savePerson(Person p) {
		return personRepository.save(p);
	}
}
