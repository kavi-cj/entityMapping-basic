package com.example.demo.dto;

import java.util.List;

import lombok.Data;

@Data
public class PersonDTO {

	private String firstName;

	private String lastName;

	private String dateOfBirth;
	
	private List<PassportDTO> passports;

}
