package com.example.demo.dto;

import lombok.Data;

@Data
public class PassportDTO {

	private String passportNumber;
	
	private String issueCountry;
	
	private String expirationDate;

}
