package com.example.demo.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.dto.PassportDTO;
import com.example.demo.dto.PersonDTO;
import com.example.demo.entity.Passport;
import com.example.demo.entity.Person;
import com.example.demo.service.PersonService;

@RestController
public class PersonController {

	@Autowired
	private PersonService personService;
	
	@GetMapping("/person/{id}")
	public Person getPerson(@PathVariable Long id) {
		Optional<Person> person = personService.getPersonById(id);
		return person.orElse(null);
	}
	
	@PostMapping("/save")
	public Person savePerson(@RequestBody PersonDTO personDto) {
		
		Person person = new Person();
		person.setFirstName(personDto.getFirstName());
		person.setLastName(personDto.getLastName());
		person.setDateOfBirth(personDto.getDateOfBirth());
		
		List<Passport> pList = new ArrayList<>();
		for (PassportDTO pp : personDto.getPassports()) {
			Passport pass = new Passport();
			pass.setExpirationDate(pp.getExpirationDate());
			pass.setIssueCountry(pp.getIssueCountry());
			pass.setPassportNumber(pp.getPassportNumber());
			pass.setPerson(person);
			
			pList.add(pass);
			
		}
		
		person.setPassports(pList);
		return personService.savePerson(person);
		
	}
}
